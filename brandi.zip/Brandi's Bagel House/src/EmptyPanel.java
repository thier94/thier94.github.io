import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * This empty Panel is used for design purpose
 */
public class EmptyPanel extends JPanel
{
	public EmptyPanel ()
	{
		// Setting the visibility of the panel
		setVisible (true);
	}
}
